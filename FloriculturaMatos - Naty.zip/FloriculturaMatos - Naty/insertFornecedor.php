<?php
include_once './conexao.php';
include_once './usuarioProprietaria.php';
session_start();

if (!isset($_SESSION['user'])) {
    $_SESSION['msg'] = "É necessário logar antes de acessar a página de menu!";
    header("Location: index.php");
    exit;   
}

header('Content-Type: application/json');

$user = $_SESSION['user']->user; 

if (
    isset($_POST['fornecedor']) &&
    isset($_POST['email_fornecedor']) &&
    isset($_POST['telefone']) &&
    isset($_POST['cnpj_fornecedor']) &&
    isset($_POST['rua_fornecedor']) &&
    isset($_POST['numero_fornecedor']) &&
    isset($_POST['bairro_fornecedor']) &&
    isset($_POST['cidade_fornecedor']) &&
    isset($_POST['estado_fornecedor']) &&
    isset($_POST['cep_fornecedor'])
) {
 
    $fornecedor = trim($_POST['fornecedor']);
    $email = trim($_POST['email_fornecedor']);
    $telefone = trim($_POST['telefone']);
    $cnpj = trim($_POST['cnpj_fornecedor']);
    $rua = trim($_POST['rua_fornecedor']);
    $numero = trim($_POST['numero_fornecedor']);
    $complemento = isset($_POST['complemento_fornecedor']) ? trim($_POST['complemento_fornecedor']) : '';
    $bairro = trim($_POST['bairro_fornecedor']);
    $cidade = trim($_POST['cidade_fornecedor']);
    $estado = trim($_POST['estado_fornecedor']);
    $cep = intval($_POST['cep_fornecedor']);

    $sql = "INSERT INTO fornecedor (
        fornecedor, email_fornecedor, telefone, cnpj_fornecedor,
        rua_fornecedor, numero_fornecedor, complemento_fornecedor, bairro_fornecedor,
        cidade_fornecedor, estado_fornecedor, cep_fornecedor, user
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        "sssssssssssi",
        $fornecedor, $email, $telefone, $cnpj,
        $rua, $numero, $complemento, $bairro,
        $cidade, $estado, $cep, $user
    );

    if ($stmt->execute()) {
        http_response_code(200);
        $msg = "Fornecedor cadastrado com sucesso!";
    } else {
        http_response_code(400);
        $msg = "Erro ao cadastrar: " . $stmt->error;
    }

    $stmt->close();
} else {
    http_response_code(400);
    $msg = "Erro: Dados obrigatórios não foram preenchidos.";
}

$conn->close();
echo json_encode(['msg' => $msg]);
?>
