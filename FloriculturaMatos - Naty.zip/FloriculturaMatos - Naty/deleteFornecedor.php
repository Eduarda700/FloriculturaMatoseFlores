<?php
include_once './conexao.php';
include_once './usuarioProprietaria.php';
session_start();

if (!isset($_SESSION['user'])){
    $_SESSION['msg'] = "É necessário logar antes de acessar a página de menu!!";
    header("Location: index.php");
    exit;   
}

if (isset($_POST['idfornecedor'])) {
    $id = intval($_POST['idfornecedor']);

    $stmt = $conn->prepare("DELETE * FROM fornecedor WHERE idfornecedor = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo json_encode(['msg' => 'Fornecedor excluído com sucesso!']);
    } else {
        echo json_encode(['msg' => 'Erro ao excluir fornecedor.']);
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(['msg' => 'ID do fornecedor não fornecido.']);
}
?>
